Scanner to scan port

import SnakeScan

and use module to scan port 

requires=>tqdm,termcolor,art

added new single search:
    
[$]Port--> --s 50

requires-python=>3.9

added new check all port search:
 [$]Port--> --a 
added new check all port using thread:
 [$]Port--> --t 
 added new dos attack:
     [$]Host-->https://example.com --d
 
 